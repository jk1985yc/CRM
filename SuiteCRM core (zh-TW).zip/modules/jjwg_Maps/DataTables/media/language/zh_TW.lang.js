{
    "sEmptyTable":     "表格中無資料",
    "sInfo":           "顯示 _START_ 到 _END_ 共有 _TOTAL_ 資料",
    "sInfoEmpty":      "顯示 0 到 0 共有 0 資料",
    "sInfoFiltered":   "(過濾自 _MAX_ 資料)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ",",
    "sLengthMenu":     "顯示 _MENU_ 資料",
    "sLoadingRecords": "載入中...",
    "sProcessing":     "處理中...",
    "sSearch":         "搜尋:",
    "sZeroRecords":    "找不到匹配資料",
    "oPaginate": {
        "sFirst":    "第一頁",
        "sLast":     "最後頁",
        "sNext":     "下一頁",
        "sPrevious": "前一頁"
    },
    "oAria": {
        "sSortAscending":  ": 啟動欄位正序排列",
        "sSortDescending": ": 啟動欄位倒序排列"
    }
}